<?php

define('root', realpath(dirname(__FILE__)));
define('inc', '/includes');
define('net', '/network');

?>