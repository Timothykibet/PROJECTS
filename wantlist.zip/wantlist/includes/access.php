<?php

if (isset($_POST['login-btn'])) {
    $username = $_POST['username'];
    $account = $_POST['account'];
    $pass = $_POST['password'];

    if (match_data(ur,$account)) {
        $get = "select * from users where username = ?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$username);
        $fetch->execute();
        $result = $fetch->get_result();
        if (!empty($result)) {
            $details = $result->fetch_assoc();
            if (password_verify($pass,$details['password'])) {
                $_SESSION['account'] = $account;
                $_SESSION['username'] = $username;
                $_SESSION['email'] = $details['email'];

                $_SESSION['login-message'] = 'your are now logged in';
                $_SESSION['login-success'] = 'alert alert-success';

                location('index.php?id=0');
            }
            else {
                echo "<script>alert('Password is incorrect');</script>";
            }
        }
        else {
            echo "<script>alert('User ".$username." does not exits');</script>";
        }
    }
    elseif (match_data(sup,$account)) {
        $get = "select * from suppliers where username = ?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$username);
        $fetch->execute();
        $result = $fetch->get_result();
        if (!empty($result)) {
            $details = $result->fetch_assoc();
            if (password_verify($pass,$details['password'])) {
                $_SESSION['account'] = $account;
                $_SESSION['username'] = $username;
                $_SESSION['email'] = $details['email'];

                $_SESSION['login-message'] = 'your are now logged in';
                $_SESSION['login-success'] = 'alert alert-success';

                location('supplier.php?id=0');
            }
            else {
                echo "<script>alert('Password is incorrect');</script>";
            }
        }
        else {
            echo "<script>alert('Supplier ".$username." does not exits');</script>";
        }
    }
    else {
        echo "<script>alert('Choose an account type to proceed');</script>";
    }
    
}


// user account codes
if (isset($_POST['request'])) {
    $names = $_POST['item'];
    $description = $_POST['item-description'];
    $time = date('Y-m-d h:i:s');

    $request = "insert into list(name,description,posted_by,posted_on)
                values(?,?,?,?);";
    $send = $net->prepare($request);
    $send->bind_param('ssss',$names,$description,$_SESSION['username'],$time);
    if ($send->execute()) {

        echo "<script>alert('Request for item ".$names." has successfully been sent')</script>";
    }
    else {
        echo "<script>alert('Request for item ".$names." has successfully been sent')</script>";
    }
}

if (isset($_POST['change-user-pass'])) {
    $pass = $_POST['pass'];
    $cpass = $_POST['conf_pass'];

    if (match_data($pass,$cpass)) {
        if ((validate_input($small,$pass)) && (validate_input($caps,$pass)) && (validate_input($int,$pass))) {
            $password = password_hash($pass, PASSWORD_DEFAULT);

            $new = "update users set password = ? where email = ?";
            $update = $net->prepare($new);
            $update->bind_param('ss',$password,$_SESSION['email']);
            if ($update->execute()) {
                echo "<script>alert('Password successfully updated');</script>";
            }
            else {
                echo "<script>alert('Cannont update your password at the moment . . .');</script>";
            }
        }
        else {
            echo "<script>alert('Password should only contain a-z, A-Z and 0-9');</script>";
        }
    }
    else {
        echo "<script>alert('The two passwords do not match_data');</script>";
    }
}

//supplier account codes
if (isset($_POST['change-supplier-pass'])) {
    $pass = $_POST['pass'];
    $cpass = $_POST['conf_pass'];

    if (match_data($pass,$cpass)) {
        if ((validate_input($small,$pass)) && (validate_input($caps,$pass)) && (validate_input($int,$pass))) {
            $password = password_hash($pass, PASSWORD_DEFAULT);

            $new = "update suppliers set password = ? where email = ?";
            $update = $net->prepare($new);
            $update->bind_param('ss',$password,$_SESSION['email']);
            if ($update->execute()) {
                echo "<script>alert('Password successfully updated');</script>";
            }
            else {
                echo "<script>alert('Cannont update your password at the moment . . .');</script>";
            }
        }
        else {
            echo "<script>alert('Password should only contain a-z, A-Z and 0-9');</script>";
        }
    }
    else {
        echo "<script>alert('The two passwords do not match');</script>";
    }
}

//code for response
if (isset($_GET['user']) && isset($_GET['item']) && isset($_GET['description'])) {
    $user = base64_decode($_GET['user']);
    $item = base64_decode($_GET['item']);
    $description = base64_decode($_GET['description']);
    $dateposted = base64_decode($_GET['dateposted']);
    $respondedOn = date('Y-m-d h:i:s');

    $response = "insert into response(name,description,posted_by,posted_on,responded_by,contact,responded_on)
                values(?,?,?,?,?,?,?);";
    $send = $net->prepare($response);
    $send->bind_param('sssssss',$item,$description,$user,$dateposted,$_SESSION['username'],$_SESSION['phone'],$respondedOn);
    if ($send->execute()) {
        echo "<script>alert('Response for item ".$item." has successfully been sent');</script>";

        $get = "select email from users where username = ?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$user);
        $fetch->execute();
        $result = $fetch->get_result();
        $details = $result->fetch_assoc();
        sendResponse($details['email'],$item,$description,$user,$dateposted,$_SESSION['username'],$respondedOn,$_SESSION['phone']);
        unset($_SESSION['phone']);
    }
    else {
        echo "<script>alert('Can not send your response at the moment');</script>";
    }
}

//code for forgot password
if (isset($_POST['findUser'])) {
    $username = $_POST['username'];
    $account = $_POST['account'];

    if (match_data(ur,$account)) {
        $check = "select * from users where username = ?;";
        $fetch = $net->prepare($check);
        $fetch->bind_param('s',$username);
        $fetch->execute();
        $results = $fetch->get_result();
        $users = $results->num_rows;

        if (!match_data(0,$users)) {
            $details = $results->fetch_assoc();
            $_SESSION['email'] = base64_encode($details['email']);
            $_SESSION['reset'] = base64_encode($details['reset']);
            $_SESSION['username'] = base64_encode($username);
            $_SESSION['account'] = base64_encode($account);

            location('login.php?id=2');
        }
        else {
            echo "<script>alert('".$username." does not exist in our records');</script>";
        }
    }
    elseif (match_data(sup,$account)) {
        $check = "select * from suppliers where username = ?;";
        $fetch = $net->prepare($check);
        $fetch->bind_param('s',$username);
        $fetch->execute();
        $results = $fetch->get_result();
        $users = $results->num_rows;

        if (!match_data(0,$users)) {
            $details = $results->fetch_assoc();
            $_SESSION['email'] = base64_encode($details['email']);
            $_SESSION['reset'] = base64_encode($details['reset']);
            $_SESSION['username'] = base64_encode($username);
            $_SESSION['account'] = base64_encode($account);

            location('login.php?id=2');
        }
        else {
            echo "<script>alert('".$username." does not exist in our records');</script>";
        }
    }
    else {
        echo "<script>alert('Select an account type to proceed');?></script>";
    }
}

if (isset($_POST['send-reset'])) {
    $email = base64_decode($_SESSION['email']);
    $reset = base64_decode($_SESSION['reset']);
    $username = base64_decode($_SESSION['username']);
    $account = base64_decode($_SESSION['account']);
    sendpasswordReset($email,$reset,$username,$account);
    echo "<script>alert('Password reset link sent to ".$email."');</script>";
    unset($_SESSION['email']);
    unset($_SESSION['reset']);
    unset($_SESSION['username']);
    unset($_SESSION['account']);
}

if (isset($_POST['reset-password'])) {
    $pass = $_POST['password'];
    $cpass = $_POST['conf_password'];

    if (match_data(ur,$_SESSION['account'])) {
        $get = "select * from users where username =?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$_SESSION['username']);
        $fetch->execute();
        $results = $fetch->get_result();
        $users = $results->num_rows;
        if (!match_data(0,$users)) {
            $details = $results->fetch_assoc();
            if (match_data($details['reset'],$_SESSION['reset'])) {
                if (match_data($pass,$cpass)) {
                    if ((validate_input($small,$pass)) && (validate_input($caps,$pass)) && (validate_input($int,$pass))) {
                        $password = password_hash($pass, PASSWORD_DEFAULT);
                        $update = "update users set reset = ?,password = ? where username = ?;";
                        $send = $net->prepare($update);
                        $send->bind_param('sss',$rtoken,$password,$_SESSION['username']);
                        if ($send->execute()) {
                            echo "<script>alert('Password has successfully been reset');</script>";
                            unset($_SESSION['username']);
                            unset($_SESSION['reset']);
                            unset($_SESSION['account']);
                        }
                        else {
                            echo "<script>alert('Cannot reset your password at the moment, please request a new reset link');</script>";
                            unset($_SESSION['username']);
                            unset($_SESSION['reset']);
                            unset($_SESSION['account']);
                        }
                    }
                    else {
                        echo "<script>alert('Password should only contain a-z, A-Z and 0-9');</script>";
                    }
                }
                else {
                    echo "<script>alert('The two passwords do not match');</script>";
                }
            }
            else {
                echo "<script>alert('Cannot reset your password at the moment, please request a new reset link');</script>";
                unset($_SESSION['username']);
                unset($_SESSION['reset']);
                unset($_SESSION['account']);
            }
        }
        else {
            echo "<script>alert('Cannot reset your password at the moment, please request a new reset link');</script>";
            unset($_SESSION['username']);
                unset($_SESSION['reset']);
                unset($_SESSION['account']);
        }
    }
    elseif (match_data(sup,$_SESSION['account'])) {
        $get = "select * from suppliers where username =?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$_SESSION['username']);
        $fetch->execute();
        $results = $fetch->get_result();
        $users = $results->num_rows;
        if (!match_data(0,$users)) {
            $details = $results->fetch_assoc();
            if (match_data($details['reset'],$_SESSION['reset'])) {
                if (match_data($pass,$cpass)) {
                    if ((validate_input($small,$pass)) && (validate_input($caps,$pass)) && (validate_input($int,$pass))) {
                        $password = password_hash($pass, PASSWORD_DEFAULT);
                        $update = "update suppliers set reset = ?,password = ? where username = ?;";
                        $send = $net->prepare($update);
                        $send->bind_param('sss',$rtoken,$password,$_SESSION['username']);
                        if ($send->execute()) {
                            echo "<script>alert('Password has successfully been reset');</script>";
                            unset($_SESSION['username']);
                            unset($_SESSION['reset']);
                            unset($_SESSION['account']);
                        }
                        else {
                            echo "<script>alert('Cannot reset your password at the moment, please request a new reset link');</script>";
                            unset($_SESSION['username']);
                            unset($_SESSION['reset']);
                            unset($_SESSION['account']);
                        }
                    }
                    else {
                        echo "<script>alert('Password should only contain a-z, A-Z and 0-9');</script>";
                    }
                }
                else {
                    echo "<script>alert('The two passwords do not match');</script>";
                }
            }
            else {
                echo "<script>alert('Cannot reset your password at the moment, please request a new reset link');</script>";
                unset($_SESSION['username']);
                unset($_SESSION['reset']);
                unset($_SESSION['account']);
            }
        }
        else {
            echo "<script>alert('Cannot reset your password at the moment, please request a new reset link');</script>";
            unset($_SESSION['username']);
                unset($_SESSION['reset']);
                unset($_SESSION['account']);
        }
    }
    else {
        unset($_SESSION['username']);
        unset($_SESSION['reset']);
        unset($_SESSION['account']);
    }
}

/*
code account deletion
1. Supplier account
*/

if (isset($_POST['delete-account-supplier'])) {
    $pass = $_POST['password'];
    $get = "select * from suppliers where username = ?;";
    $fetch = $net->prepare($get);
    $fetch->bind_param('s',$_SESSION['username']);
    $fetch->execute();
    $result = $fetch->get_result();
    $details = $result->fetch_assoc();
    if (password_verify($pass,$details['password'])) {
        $fetch->close();
        $result->free_result();
        $get = "select * from response where responded_by = ?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$_SESSION['user']);
        $fetch->execute();
        $result = $fetch->get_result();
        $count = $result->num_rows;
        if (!match_data(0,$count)) {
            $delRes = "delete from response where responded_by = ?;";
            $send = $net->prepare($delRes);
            $send->bind_param('s',$_SESSION['username']);
            $send->execute();
            $send->close();
            $delAcc = "delete from suppliers where username = ?;";
            $send = $net->prepare($delAcc);
            $send->bind_param('s',$_SESSION['username']);
            if ($send->execute()) {
                location('login.php?id=0');
            }
            else {
                echo "<script>alert('Cannot process your request at the moment, try again later . . .');</script>";
            }
        }
        else {
            $delAcc = "delete from suppliers where username = ?;";
            $send = $net->prepare($delAcc);
            $send->bind_param('s',$_SESSION['username']);
            if ($send->execute()) {
                location('login.php?id=0');
            }
            else {
                echo "<script>alert('Cannot process your request at the moment, try again later . . .');</script>";
            }
        }
    }
    else {
        echo "<script>alert('Password is incorrect');</script>";
    }
}

//user account deletion
if (isset($_POST['delete-account-user'])) {
    $pass = $_POST['password'];
    $get = "select * from users where username = ?;";
    $fetch = $net->prepare($get);
    $fetch->bind_param('s',$_SESSION['username']);
    $fetch->execute();
    $result = $fetch->get_result();
    $details = $result->fetch_assoc();
    if (password_verify($pass,$details['password'])) {
        $fetch->close();
        $result->free_result();
        $get = "select * from response where posted_by = ?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$_SESSION['user']);
        $fetch->execute();
        $result = $fetch->get_result();
        $count = $result->num_rows;
        if (!match_data(0,$count)) {
            $fetch->close();
            $result->free_result();
            $delRes = "delete from response where posted_by = ?;";
            $send = $net->prepare($delRes);
            $send->bind_param('s',$_SESSION['username']);
            $send->execute();
            $send->close();
            $check = "select * from list where posted_by = ?;";
            $fetch = $net->prepare($check);
            $fetch->bind_param('s',$_SESSION['username']);
            $fetch->execute();
            $result = $fetch->get_result();
            $count = $result->num_rows;
            if (!match_data(0,$count)) {
                $fetch->close();
                $result->free_result();
                $delPos = "delete from list where posted_by = ?;";
                $send = $net->prepare($delPos);
                $send->bind_param('s',$_SESSION['username']);
                $send->execute();
                $send->close();
                $delAcc = "delete from users where username = ?;";
                $send = $net->prepare($delAcc);
                $send->bind_param('s',$_SESSION['username']);
                if ($send->execute()) {
                    session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);

                    location('supplier.php?id=0');
                }
                else {
                    echo "<script>alert('Cannot process your request at the moment');</script>";
                }
            }
            else {
                $delAcc = "delete from users where username = ?;";
                $send = $net->prepare($delAcc);
                $send->bind_param('s',$_SESSION['username']);
                if ($send->execute()) {
                    session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);

                    location('supplier.php?id=0');
                }
                else {
                    echo "<script>alert('Cannot process your request at the moment');</script>";
                }
            }
        }
        else {
            $check = "select * from list where posted_by = ?;";
            $fetch = $net->prepare($check);
            $fetch->bind_param('s',$_SESSION['username']);
            $fetch->execute();
            $result = $fetch->get_result();
            $count = $result->num_rows;
            if (!match_data(0,$count)) {
                $fetch->close();
                $result->free_result();
                $delPos = "delete from list where posted_by = ?;";
                $send = $net->prepare($delPos);
                $send->bind_param('s',$_SESSION['username']);
                $send->execute();
                $send->close();
                $delAcc = "delete from users where username = ?;";
                $send = $net->prepare($delAcc);
                $send->bind_param('s',$_SESSION['username']);
                if ($send->execute()) {
                    session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);

                    location('supplier.php?id=0');
                }
                else {
                    echo "<script>alert('Cannot process your request at the moment');</script>";
                }
            }
            else {
                $delAcc = "delete from users where username = ?;";
                $send = $net->prepare($delAcc);
                $send->bind_param('s',$_SESSION['username']);
                if ($send->execute()) {
                    session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);

                    location('supplier.php?id=0');
                }
                else {
                    echo "<script>alert('Cannot process your request at the moment');</script>";
                }
            }
        }
    }
    else {
        echo "<script>alert('Password is incorrect');</script>";
    }
}

//Supplier account activation
if (isset($_POST['activate_account'])) {
    $get = "select * from suppliers where email = ? limit 1;";
    $fetch = $net->prepare($get);
    $fetch->bind_param('s',$_SESSION['email']);
    $fetch->execute();
    $result = $fetch->get_result();
    $details = $result->fetch_assoc();
    $acode = $_POST['acode'];
    $activatednow = true;
    $email = $details['email'];
    if (match_data($details['activation_code'],$acode)) {
        $fetch->close();
        $result->free_result();
        $update = "update suppliers set activated = ? where email = ?;";
        $send = $net->prepare($update);
        $send->bind_param('ss',$activatednow,$email);
        if ($send->execute()) {
            location('supplier.php?id=0');
        }
        else {
            echo "<script>alert('Can not activate your account at the moment try again later');</script>";
        }
    }
    else {
        echo "<script>alert('You have entered the incorrect activation code. Check your email and try again . . .');</script>";
    }
}
?>