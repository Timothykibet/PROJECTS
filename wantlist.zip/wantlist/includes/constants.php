<?php

define('id', isset($_GET['id']) ? (int)$_GET['id']: 0);
define('yr', date('Y'));

define('ur', 'user');
define('sup', 'supplier');

define('ur_table', 'users');
define('sup_table', 'suppliers');

define('n_field', 'names');
define('u_field', 'username');
define('e_field', 'email');
define('p_field', 'phone');

$names = '';
$username = '';
$email = '';
$phone = '';
$description = '';

$small = '/[-a-z]/';
$caps = '/[-A-Z]/';
$int = '/[0-9]/';

$token = bin2hex(random_bytes(5));
$rtoken = bin2hex(random_bytes(6));
$acode = bin2hex(random_bytes(2));
$none = 'Not available';
$no = false;

define('EMAIL', 'wantlist2021@gmail.com');
define('PASSWORD', 'Timz00123');
?>