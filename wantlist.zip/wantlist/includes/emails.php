<?php

require_once 'vendor/autoload.php';

$transport = (new Swift_SmtpTransport('smtp.gmail.com', 465, 'ssl'))
    ->setUsername(EMAIL)
    ->setPassword(PASSWORD);
$mailer = new Swift_Mailer($transport);

function sendverificationMail ($userMail,$token,$user,$account) {
    global $mailer;

    $etoken = base64_encode($token);
    $euser = base64_encode($user);
    $eaccount = base64_encode($account);
    $body = '
        <!DOCTYPE html>
            <html lang="en">

            <head>
                <meta charset="UTF-8">
                <title>Verify Email</title>
            </head>

            <body>
                <div class="wrapper">
                    <p>
                        Thank you for signing up on Want List. Please click the link below to verify your email.
                    </p>
                    <a href="http://localhost/wantlist/login.php?id=0&&etoken='.$etoken.'&&euser='.$euser.'&&eaccount='.$eaccount.'">
                        Verify your email address
                    </a>
                </div>
            </body>

        </html>
        ';
    

    $message = (new Swift_Message('Verify Email Address'))
    ->setFrom(EMAIL)
    ->setTo($userMail)
    ->setBody($body, 'text/html');

    $result = $mailer->send($message);
}

function sendpasswordReset($userEmail,$rkey,$user,$account) {
    global $mailer;

    $erkey = base64_encode($rkey);
    $euser = base64_encode($user);
    $eaccount = base64_encode($account);

    $body = '
    <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <title>Password Reset</title>
        </head>

        <body>
            <div class="wrapper">
                <p>
                    We have received a password reset request for your account.<br>
                    Click <a href="http://localhost/wantlist/login.php?id=3&&ereset='.$erkey.'&&eruser='.$euser.'&&eraccount='.$eaccount.'">here</a>&nbsp;to reset your password.<br>
                    Please ignore if it was not your request.
                </p>
                
            </div>
        </body>

    </html>
    ';

    $message = (new Swift_Message('Password Reset'))
    ->setFrom(EMAIL)
    ->setTo($userEmail)
    ->setBody($body, 'text/html');

    $result = $mailer->send($message);
}

function sendResponse($userEmail,$item,$description,$posted_by,$posted_on,$responded_by,$responded_on,$contact) {
    global $mailer;

    $body = '
    <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="UTF-8">
            <title>Password Reset</title>
        </head>

        <body>
            <div class="wrapper">
                <p>
                    Dear user '.$posted_by.',<br>
                    supplier '.$responded_by.' responded to your request of :<br><br>
                    Item : '.$item.'<br>
                    Description :
                    <pre>'.$description.'</pre>
                    Requested on : '.$posted_on.'<br><br>
                    Responded on : '.$responded_on.'.<br>
                    You can contact supplier '.$responded_by.' via '.$contact.'.
                </p>
                
            </div>
        </body>

    </html>
    ';

    $message = (new Swift_Message('Want List Item response'))
    ->setFrom(EMAIL)
    ->setTo($userEmail)
    ->setBody($body, 'text/html');

    $result = $mailer->send($message);
}
?>