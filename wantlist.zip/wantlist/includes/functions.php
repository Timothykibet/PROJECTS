<?php

function ex_det($con,$table,$field,$input) {
    $det = "select * from $table where $field = ? limit 1;";
        $get = $con->prepare($det);
        $get->bind_param('s',$input);
        $get->execute();
        $result = $get->get_result();
        $count = $result->num_rows;

        if ($count == 0) {
            return false;
        }
        else {
            return true;
        }
}

function match_data ($input1,$input2) {
    if ($input2 == $input1) {
        return true;
    }
    else {
        return false;
    }
}

function validate_input ($condition,$input) {
    if (preg_match($condition,$input)) {
        return true;
    }
    else {
        return false;
    }
}

function location($to) {
    header('location:'.$to);
    exit();
}

?>