<?php 

require_once 'config.php';

$net = mysqli_connect(host,user,pass,db);

if (!$net) {
    error_reporting(0);
    die("<script>alert('Failed to connect to our store at the moment');</script>");
    exit;
}
?>