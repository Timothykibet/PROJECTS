<?php 

if (isset($_POST['signup-btn'])) {
    $names = $_POST['names'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $account = $_POST['account'];
    $pass = $_POST['password'];
    $cpass = $_POST['conf_password'];

    if (match_data(ur,$account)) {
        if (!ex_det($net,ur_table,n_field,$names)) {
            if (!ex_det($net,ur_table,u_field,$username)) {
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    if (!ex_det($net,ur_table,e_field,$email)) {
                        if (validate_input($int,$phone)) {
                            if (!ex_det($net,ur_table,p_field,$phone)) {
                                if (match_data($pass,$cpass)) {
                                    if ((validate_input($small,$pass)) && (validate_input($caps,$pass)) && (validate_input($int,$pass))) {
                                        $password = password_hash($pass, PASSWORD_DEFAULT);

                                        $new = "insert into users(names,username,email,token,verified,phone,reset,password)
                                                values (?,?,?,?,?,?,?,?);";
                                        $insert = $net->prepare($new);
                                        $insert->bind_param('ssssbsss',$names,$username,$email,$token,$no,$phone,$rtoken,$password);
                                        if ($insert->execute()) {
                                            sendverificationMail ($email,$token,$username,$account);
                                            $_SESSION['account'] = $account;
                                            $_SESSION['username'] = $username;
                                            $_SESSION['email'] = $email;

                                            $_SESSION['login-message'] = 'your are now logged in';
                                            $_SESSION['login-success'] = 'alert alert-success';

                                            location('index.php?id=0');
                                        }
                                        else {
                                            echo "<script>alert('Cannont sign up new users at the moment . . .');</script>";
                                            $delete = mysqli_query($net,"delete * from users where email = '".$email.";'");
                                        }
                                    }
                                    else {
                                        echo "<script>alert('Password should only contain a-z, A-Z and 0-9');</script>";
                                    }
                                }
                                else {
                                    echo "<script>alert('The two passwords do not match');</script>";
                                }
                            }
                            else {
                                echo "<script>alert('".$phone." already exists')</script>";
                            }
                        }
                        elseif ((validate_input($small,$phone)) or validate_input($caps,$phone)) {
                            echo "<script>alert('Phone number should only contain country code and 0-9');</script>";
                        }
                        else {
                            echo "<script>alert('Phone number should only contain country code and 0-9');</script>";
                        }
                    }
                    else {
                        echo "<script>alert('".$email." address already exists');</script>";
                    }
                }
                else {
                    echo "<script>alert('".$email." ddress is invalid');</script>";
                }
            }
            else {
                echo "<script>alert('".$username." already exists');</script>";
            }
        }
        else {
            echo "<script>alert('".$names." already exists');</script>";
        }
    }
    elseif (match_data(sup,$account)) {
        if (!ex_det($net,sup_table,n_field,$names)) {
            if (!ex_det($net,sup_table,u_field,$username)) {
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    if (!ex_det($net,sup_table,e_field,$email)) {
                        if (validate_input($int,$phone)) {
                            if (!ex_det($net,sup_table,p_field,$phone)) {
                                if (match_data($pass,$cpass)) {
                                    if ((validate_input($small,$pass)) && (validate_input($caps,$pass)) && (validate_input($int,$pass))) {
                                        $password = password_hash($pass, PASSWORD_DEFAULT);

                                        $new = "insert into suppliers(names,username,email,token,verified,phone,activated,activation_code,activation_date,reset,password)
                                                values (?,?,?,?,?,?,?,?,?,?,?);";
                                        $insert = $net->prepare($new);
                                        $insert->bind_param('sssssssssss',$names,$username,$email,$token,$no,$phone,$no,$acode,$none,$rtoken,$password);
                                        if ($insert->execute()) {
                                            sendverificationMail ($email,$token,$username,$account);
                                            $_SESSION['account'] = $account;
                                            $_SESSION['username'] = $username;
                                            $_SESSION['email'] = $email;

                                            $_SESSION['login-message'] = 'your are now logged in';
                                            $_SESSION['login-success'] = 'alert alert-success';

                                            location('supplier.php?id=0');
                                        }
                                        else {
                                            echo "<script>alert('Cannont sign up new users at the moment . . .');</script>";
                                        }
                                    }
                                    else {
                                        echo "<script>alert('Password should only contain a-z, A-Z and 0-9');</script>";
                                    }
                                }
                                else {
                                    echo "<script>alert('The two passwords do not match');</script>";
                                }
                            }
                            else {
                                echo "<script>alert('".$phone." already exists')</script>";
                            }
                        }
                        elseif ((validate_input($small,$phone)) or validate_input($caps,$phone)) {
                            echo "<script>alert('Phone number should only contain country code and 0-9');</script>";
                        }
                        else {
                            echo "<script>alert('Phone number should only contain country code and 0-9');</script>";
                        }
                    }
                    else {
                        echo "<script>alert('".$email." address already exists');</script>";
                    }
                }
                else {
                    echo "<script>alert('".$email." ddress is invalid');</script>";
                }
            }
            else {
                echo "<script>alert('".$username." already exists');</script>";
            }
        }
        else {
            echo "<script>alert('".$names." already exists');</script>";
        }
    }
    else {
        echo "<script>alert('Choose an account type to proceed');</script>";
    }
}


?>