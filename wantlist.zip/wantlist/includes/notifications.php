<?php 

if(isset($_GET['etoken']) && isset($_GET['euser']) && isset($_GET['eaccount'])) {
    $token = base64_decode($_GET['etoken']);
    $user = base64_decode($_GET['euser']);
    $account = base64_decode($_GET['eaccount']);
    $verified = true;

    if (match_data(ur,$account)) {
        $get = "select * from users where username = ?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$user);
        $fetch->execute();
        $result = $fetch->get_result();
        $count = $result->num_rows;

        if (!match_data(0,$count)) {
            $details = $result->fetch_assoc();
            if (match_data($details['token'],$token)) {
                $verify = "update users set verified = ? where username = ?;";
                $send = $net->prepare($verify);
                $send->bind_param('ss',$verified,$user);
                if ($send->execute()) {
                    session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);

                    location('index.php');
                }
                else {
                    echo "<script>alert('Cannot verify your account at the moment, please sign up again');</script>";
                    $delet = mysqli_query($net,"delete * from users where username = '".$user."' limit 1;");
                    session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);
                    location('login.php');
                }
            }
            else {
                echo "<script>alert('Invalid token, please sign up again');</script>";
                $delet = mysqli_query($net,"delete * from users where username = '".$user."' limit 1;");
                session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);
                location('login.php');
            }
        }
        else {
            echo "<script>alert('Cannot verify your account at the moment, please sign up again');</script>";
            $delet = mysqli_query($net,"delete * from users where username = '".$user."' limit 1;");
            session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);
            location('login.php');
        }
    }
    elseif (match_data(sup,$account)) {
        $get = "select * from suppliers where username = ?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$user);
        $fetch->execute();
        $result = $fetch->get_result();
        $count = $result->num_rows;

        if (!match_data(0,$count)) {
            $details = $result->fetch_assoc();
            if (match_data($details['token'],$token)) {
                $verify = "update suppliers set verified = ? where username = ?;";
                $send = $net->prepare($verify);
                $send->bind_param('ss',$verified,$user);
                if ($send->execute()) {
                    session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);

                    location('index.php');
                }
                else {
                    echo "<script>alert('Cannot verify your account at the moment, please sign up again');</script>";
                    $delet = mysqli_query($net,"delete * from suppliers where username = '".$user."' limit 1;");
                    session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);
                    location('login.php');
                }
            }
            else {
                echo "<script>alert('Invalid token, please sign up again');</script>";
                $delet = mysqli_query($net,"delete * from suppliers where username = '".$user."' limit 1;");
                session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);
                location('login.php');
            }
        }
        else {
            echo "<script>alert('Cannot verify your account at the moment, please sign up again');</script>";
            $delet = mysqli_query($net,"delete * from suppliers where username = '".$user."' limit 1;");
            session_destroy();
    
                    unset($_SESSION['account']);
                    unset($_SESSION['username']);
                    unset($_SESSION['email']);

                    unset($_SESSION['login-message']);
                    unset($_SESSION['login-success']);
            location('login.php');
        }
    }
    else {
        location('login.php?id=0');
    }
}

if(isset($_GET['ereset']) && isset($_GET['euser']) && isset($_GET['eaccount'])) {
    $reset = base64_decode($_GET['ereset']);
    $user = base64_decode($_GET['euser']);
    $account = base64_decode($_GET['eaccount']);
}
?>