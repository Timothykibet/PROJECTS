<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
<link rel="stylesheet" href="includes/css/bootstrap.css">
<link href="includes/css/fontawesome/css/all.css" rel="stylesheet">
<link href="includes/css/fontawesome/css/brands.css" rel="stylesheet">
<link href="includes/css/fontawesome/css/fontawesome.css" rel="stylesheet">
<link href="includes/css/fontawesome/css/regular.css" rel="stylesheet">
<link href="includes/css/fontawesome/css/solid.css" rel="stylesheet">
<link href="includes/css/wantList.css" rel="stylesheet">