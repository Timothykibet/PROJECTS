<?php

$get = "select * from suppliers where email = ? limit 1;";
$fetch = $net->prepare($get);
$fetch->bind_param('s',$_SESSION['email']);
$fetch->execute();
$result = $fetch->get_result();
$details = $result->fetch_assoc();

if (isset($_GET['logout'])) {
    session_destroy();
    
    unset($_SESSION['account']);
    unset($_SESSION['username']);
    unset($_SESSION['email']);

    unset($_SESSION['login-message']);
    unset($_SESSION['login-success']);

    location('supplier.php?id=0');
}
?>