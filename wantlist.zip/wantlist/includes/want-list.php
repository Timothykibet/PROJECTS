<?php 

require root.inc.'/emails.php';
require root.inc.'/notifications.php';

require root.inc.'/new.php';

require root.inc.'/access.php';
?>