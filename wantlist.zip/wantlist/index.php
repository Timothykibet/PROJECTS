<?php 

require 'load.php';

if (!isset($_SESSION['account']) && !isset($_SESSION['username']) &&!isset($_SESSION['email'])) {
    location('login.php?id=0');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once root.inc.'/references.php';?>
    <title>Want List | Home &nbsp;&rsaquo;&nbsp;account</title>
    <script>
        window.onload
        <?php require root.inc.'/index-account.php'; ?>
    </script>
</head>
<body>

<div class="container mt-2">
<?php require_once root.inc.'/head.php';?>
    <div class="row mt-4 justify-content-center">
        <div class="alert alert-warning"><h3>Client Area</h3></div>
    </div>
    <div class="row justify-content-center mt-auto">
        <div class="fit"><i class="fa fa-user-circle"></i></div>
        <div class="fit ml-2"><?php echo $_SESSION['username'];?></div>
    </div>
    <div class="row mt-2 justify-content-center mt-3">
        <div class="fit mt-2 pl-5 pr-5">
            <div class="row justify-content-center">
                <a href="index.php?id=0" class="fit btn btn-outline-dark" title="Dashboard">Home</a>
                <a href="index.php?id=1" class="fit btn btn-outline-dark ml-4" title="view profile">Profile</a>
                <a href="index.php?id=2" class="fit btn btn-outline-info ml-4" title="view settings">Settings</a>
                <a href="index.php?logout" class="fit btn btn-outline-danger mt-1  ml-4" title="Sign out">Logout</a>
            </div>
        </div>
    </div>
    
<?php

if ($_GET['id'] != 3):
?>

<div class="row mt-2 justify-content-center mt-3">
    <div class="fit mt-2">
        <div class="row justify-content-center">
            <a href="index.php?id=3" class="fit btn btn-outline-info" title="view my requests">Want List</a>
        </div>
    </div>
</div>

<?php

endif;

if (isset($_SESSION['login-message'])) :
?>

<div class="row justify-content-around mt-4">
    <div class="fit <?php echo $_SESSION['login-success'];?>"><?php echo $_SESSION['username'].'&nbsp;'.$_SESSION['login-message'];?></div>
</div>

<?php

unset($_SESSION['login-message']);
unset($_SESSION['login-success']);

endif;

switch (id) {
    case 0:
?>

<div class="row mt justify-content-center mt-4">
    <form action="index.php?id=0" method="post" class="alert bg-dark">
        <div class="form-group">
            <input type="text" name="item" class="form form-control" value="<?php echo $names;?>" placeholder="Item name" required>
        </div>
        <div class="form-group">
            <textarea name="item-description" value="<?php echo $description;?>" cols="30" rows="5" class="form form-control" placeholder="Description" required></textarea>
        </div>
        <div class="form-group">
            <button type="submit" name="request" class="btn btn-outline-success" title="post request to want list">Post</button>
        </div>
    </form>
</div>

<?php
        break;
    case 1:
?>

<div class="row justify-content-center mt-4">
    <table cellpadding="6">
        <tr>
            <td>Names :</td>
            <td><?php echo $details['names'];?></td>
        </tr>
        <tr>
            <td>Account :</td>
            <?php if ($details['verified'] == false):?>
                <td colspan="2">Not Verified</td>
                <td>Click on the link <br> we sent to <b><?php echo $_SESSION['email'];?></b></td>
            <?php else:?>
                <td colspan="2">Verified</td>
            <?php endif;?>
        </tr>
        <tr>
            <td>Username :</td>
            <td><?php echo $_SESSION['username'];?></td>
        </tr>
        <tr>
            <td>Email :</td>
            <td><?php echo $_SESSION['email'];?></td>
        </tr>
        <tr>
            <td>Phone :</td>
            <td><?php echo $details['phone'];?></td>
        </tr>
    </table>
</div>

<?php
        break;
    case 2:
?>

<div class="row justify-content-center mt-4">
    <form action="index.php?id=2" method="post" class="alert bg-dark">
        <div class="form-group">
            <input type="password" name="pass" class="form form-control" placeholder="New password" required>
        </div>
        <div class="form-group">
            <input type="password" name="conf_pass" class="form form-control" placeholder="Confirm new password" required>
        </div>
        <div class="form-group">
            <button type="submit" name="change-user-pass" class="btn btn-outline-success" title="change password">Update</button>
        </div>
    </form>
</div>
<div class="row justify-content-center mt-3 mb-3" >
    <div class="fit"><a href="javascript:void(0)" id="delete-btn" class="btn btn-outline-danger" title="delete account">Delete Account</a></div>
    <div class="fit"><a href="javascript:void(0)" id="cancel-delete-btn" class="btn btn-outline-info" title="don't delete account" hidden>Cancel Delete Account</a></div>
</div>
<div id="delete-pop" class="row mt justify-content-center mt-3 mb-3" hidden>
    <form action="index.php?id=2" method="post" class="alert">
        <div class="form-group">
            <div class="input-group">
                <input type="password" name="password" class="form form-control" placeholder="Password" required="required">
                <div class="input-group-append">
                    <button type="submit" name="delete-account-user" class="btn btn-outline-danger input-group-text" title="delete account">Delete</button>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
    document.getElementById('delete-btn').onclick = function () {
        document.getElementById('delete-btn').hidden = true;
        document.getElementById('cancel-delete-btn').hidden = false;
        document.getElementById('delete-pop').hidden = false;
    }
    document.getElementById('cancel-delete-btn').onclick = function () {
        document.getElementById('cancel-delete-btn').hidden = true;
        document.getElementById('delete-pop').hidden = true;
        document.getElementById('delete-btn').hidden = false;
    }
    
</script>
<?php
        break;
    case 3:
?>

<div class="row justify-content-center mt-4 mb-3" >
<div class="fit">
    <h4 class="text-center">Want List Responses</h4>
</div>
</div>

<?php
    $get = "select * from response where posted_by = ?;";
    $fetch = $net->prepare($get);
    $fetch->bind_param('s',$_SESSION['username']);
    $fetch->execute();
    $sent = $fetch->get_result();
    $count = $sent->num_rows;
    if ((empty($count))or ($count == 0)):
?>

<div class="row justify-content-center mt-5">
<div class="fit alert alert-info">
You have no responses for your requests yet
</div>
</div>

<?php 
endif;
$requests = mysqli_fetch_all($sent, MYSQLI_ASSOC);
foreach($requests as $request):
$user = base64_encode($request['posted_by']);
$item = base64_encode($request['name']);
$description = base64_encode($request['description']);
$dateposted = base64_encode($request['posted_on']);
$response = base64_encode('yes');
?>

<div class="row justify-content-center mt-4">
    <div class="fit">Posted By :</div><div class="fit ml-2"><?php echo $request['posted_by'];?></div>
    <div class="fit ml-4">Posted On :</div><div class="fit ml-2"><?php echo $request['posted_on'];?></div>
</div>
<div class="row justify-content-center mt-3">
    <div class="fit">Item Name :</div><div class="fit ml-2"><?php echo $request['name'];?></div>
</div>
<div class="row justify-content-center mt-3">
    <div class="fit">Description :</div>
</div>
<div class="row justify-content-center mt-1">
    <div class="fit"><pre><?php echo $request['description'];?></pre></div>
</div>



<div class="row justify-content-center mt-3">
    <div class="fit">Responded By :</div><div class="fit ml-2"><?php echo $request['responded_by'];?></div>
    <div class="fit ml-4">Contact :</div><div class="fit ml-2 resp-call" title="Contact the seller"><?php echo $request['contact'];?></div>
</div>
<div class="row justify-content-center mb-5">
    <div class="fit ml-4">Responded On :</div><div class="fit ml-2"><?php echo $request['responded_on'];?></div>
</div>
<?php
        endforeach;

        break;
}
?>
</div>

</body>
</html>