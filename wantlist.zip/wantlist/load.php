<?php 

session_start();

require_once 'config.php';

require_once root.inc.'/constants.php';

require_once root.inc.net.'/net.php';

require_once root.inc.'/functions.php';

require root.inc.'/want-list.php';
?>