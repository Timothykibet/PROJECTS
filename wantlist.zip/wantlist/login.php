<?php require 'load.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once root.inc.'/references.php';?>
    <title>Want List | Sign In&nbsp;&rsaquo;&nbsp;<?php echo yr;?></title>
</head>
<body>

<div class="container mt-2">
 
<?php 

require_once root.inc.'/head.php';

switch (id) {
    case 0:
?>

<div class="row justify-content-center mt-1">
    <div class="alert alert-warning fit">
        <form action="login.php?id=0" method="post">
            <div class="form-group">
                <div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span>
					</div>
					<input type="text" name="username" class="form-control" value="<?php echo $username;?>" placeholder="Username" required>
                </div>
                <div class="input-group mb-3">
                    <input type="radio" name="account" class="ml-4 form-control-sm" value="user" required>
                    <div class="input-group-prepend ml-2">
                        <span class="input-group-text">User</i></span>
                    </div>
                    <input type="radio" name="account" class="ml-4 form-control-sm" value="supplier" required>
                    <div class="input-group-prepend ml-2">
                        <span class="input-group-text">Supplier</i></span>
                    </div>
                </div>
                <div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-key"></i></span>
					</div>
					<input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
                <div class="input-group mb-2  justify-content-center">
					<button type="submit" name="login-btn" class="btn btn-dark" title="access your want list account">Log In</button>
                </div>
                <div class="form-group">
                    <p class="text-center">Not yet a member ? <a href="signup.php" title="join want list society">Sign Up</a></p>
                    <p class="text-center"><a href="login.php?id=1" title="reset password">Forgot password</a></p>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
        break;
    case 1:
?>

<div class="row mt-1">
    <div class="alert alert-warning offset-4 fit">
        <form action="login.php?id=1" method="post">
            <div class="form-group">
                <div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span>
					</div>
					<input type="text" name="username" class="form-control" value="<?php echo $username;?>" placeholder="Username">
                </div>
                <div class="input-group mb-3">
                    <input type="radio" name="account" class="ml-4 form-control-sm" value="user" required>
                    <div class="input-group-prepend ml-2">
                        <span class="input-group-text">User</i></span>
                    </div>
                    <input type="radio" name="account" class="ml-4 form-control-sm" value="supplier" required>
                    <div class="input-group-prepend ml-2">
                        <span class="input-group-text">Supplier</i></span>
                    </div>
                </div>
                <div class="input-group mb-2  justify-content-center">
					<button type="submit" name="findUser" class="btn btn-dark" title="find account">Search</button>
                </div>
            </div>
        </form>
    </div>
</div>


<?php
        break;
    case 2:
        if (!isset($_SESSION['username']) && !isset($_SESSION['email']) && !isset($_SESSION['reset'])) {
            location('login.php?id=0');
        }
?>

<div class="row mt-1">
    <div class="alert alert-warning offset-4 fit">
        <form action="login.php?id=2" method="post">
            <div class="form-group">
                <div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span>
					</div>
					<p class="form-control"><?php echo base64_decode($_SESSION['username']);?></p>
                </div>
                <div class="form-group mb-3">
					<p>We are going to send a <br> password reset link to <strong><?php echo base64_decode($_SESSION['email']);?></strong></p>
                </div>
                <div class="input-group mb-2 justify-content-center">
					<button type="submit" name="send-reset" class="btn btn-dark" title="send password reset link">send</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
        break;
    case 3:
        if (!isset($_GET['ereset']) && !isset($_GET['eraccount']) && !isset($_GET['eruser'])) {
            location('login.php?id=0');
        }
        $_SESSION['username'] = base64_decode($_GET['eruser']);
        $_SESSION['reset'] = base64_decode($_GET['ereset']);
        $_SESSION['account'] = base64_decode($_GET['eraccount']);
?>

<div class="row mt-1">
    <div class="alert alert-warning offset-4 fit">
        <form action="login.php?id=3" method="post">
            <div class="form-group">
                <div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-user"></i></span>
					</div>
					<p class="form-control"><?php echo $_SESSION['username'];?></p>
                </div>
                <div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-key"></i></span>
					</div>
					<input type="password" name="password" class="form-control" value="" placeholder="New password">
                </div>
                <div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text"><i class="fa fa-key"></i></span>
					</div>
					<input type="password" name="conf_password" class="form-control" value="" placeholder="Confirm new password">
                </div>
                <div class="input-group mb-2  justify-content-center">
					<button type="submit" name="reset-password" class="btn btn-dark" title="cahnge password">Update</button>
                </div>
                <div class="form-group">
                    <p class="text-center"> If password change successfull view login link</p>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
        break;
}
?>
    
</div>

</body>
</html>