<?php require_once 'load.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once root.inc.'/references.php';?>
    <title>Want List | Sign Up&nbsp;&rsaquo;&nbsp;<?php echo yr;?></title>
</head>
<body>

<div class="container mt-2">

<?php require_once root.inc.'/head.php';?>

<div class="row justify-content-center mt-1">
    <div class="alert alert-warning fit">
        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
            <div class="form-group">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-user"></i></span>
                    </div>
                    <input type="text" name="names" class="form-control" value="<?php echo $names;?>" placeholder="Full names">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-user-circle"></i></span>
                    </div>
                    <input type="text" name="username" class="form-control" value="<?php echo $username;?>" placeholder="Username">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-envelope"></i></span>
                    </div>
                    <input type="email" name="email" class="form-control" value="<?php echo $email;?>" placeholder="Email">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-phone-alt"></i></span>
                    </div>
                    <input type="text" name="phone" class="form-control" value="<?php echo $phone;?>" placeholder="Mobile Phone number" minlength="13" maxlength="13">
                </div>
                <div class="input-group mb-3">
                    <input type="radio" name="account" class="ml-4 form-control-sm" value="user" required>
                    <div class="input-group-prepend ml-2">
                        <span class="input-group-text">User</i></span>
                    </div>
                    <input type="radio" name="account" class="ml-4 form-control-sm" value="supplier" required>
                    <div class="input-group-prepend ml-2">
                        <span class="input-group-text">Supplier</i></span>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">   
                        <span class="input-group-text"><i class="fa fa-key"></i></span>
                    </div>
                    <input type="password" name="password" class="form-control" placeholder="Password">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fa fa-key"></i></span>
                    </div>
                    <input type="password" name="conf_password" class="form-control" placeholder="Confirm password">
                </div>
                <div class="input-group mb-2  justify-content-center">
                    <button type="submit" name="signup-btn" class="btn btn-dark" title="join want list society">Sign Up</button>
                </div>
                <div class="form-group">
                    <p class="text-center">Already a member ? <a href="login.php" title="access your want list account">Log In</a></p>
                </div>
            </div>
        </form>
    </div>

</div>

</div>

</body>
</html>