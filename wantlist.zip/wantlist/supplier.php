<?php 

require 'load.php';

if (!isset($_SESSION['account']) && !isset($_SESSION['username']) &&!isset($_SESSION['email'])) {
    location('login.php?id=0');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once root.inc.'/references.php';?>
    <title>Want List | Home &nbsp;&rsaquo;&nbsp;account</title>
    <script>
        window.onload
        <?php require root.inc.'/supplier-account.php';?>
    </script>
</head>
<body>

<div class="container mt-2">
<?php require_once root.inc.'/head.php';?>
<?php if($details['activated'] == false) :?>
<div class="row justify-content-center mt-4">
    <div class="fit alert alert-warning">
        Please pay <br> Ksh. 1000 to <strong>+254724130456 (Timothy Kibet)</strong> <br>
        In order to access our services <br>
        Check your email (<strong><?php echo $details['email'];?></strong>) for an account activation code <br>
        If the activation code is not available, then wait for our developer to verify your payment
    </div>
</div>
<div id="procedure" class="row justify-content-center mt-4">
    <div class="fit">
        <button id="activate" type="submit" class="fit btn btn-outline-success ml-4" title="I have paid">Activate account</button>
        <a href="supplier.php?logout" class="fit btn btn-outline-danger ml-4" title="Sign out">Logout</a>
    </div>
</div>
<div id="aform" class="row justify-content-center mt-4" hidden>
    <form action="supplier.php" method="post">
        <div class="form-group">
            <div class="input-group">
                <div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-key"></i></span></div>
                <input type="text" name="acode" id="" class="form form-control" placeholder="Enter activation code">
                <button id="cactivation" type="submit" class="btn btn-outline-warning ml-4" title="Cancel activation"><i class="fa fa-times"></i></button>
            </div>
        </div>
        <div class="form-group"><button type="submit" name="activate_account" class="btn btn-outline-success" title="Activate your account now">Activate Account</button></div>
    </form>
</div>
<script>
    document.getElementById('activate').onclick = function () {
        document.getElementById('procedure').hidden = true;
        document.getElementById('aform').hidden = false;
    }
    document.getElementById('cactivation').onclick = function () {
        document.getElementById('aform').hidden = true;
        document.getElementById('procedure').hidden = false;
    }
</script>
<?php else:?>
    <div class="row mt-4 justify-content-center">
        <div class="alert alert-warning"><h3>Supplier Area</h3></div>
    </div>
    <div class="row justify-content-center mt-auto">
        <div class="fit"><i class="fa fa-user-circle"></i></div>
        <div class="fit ml-2"><?php echo $details['username'];?></div>
    </div>
    <div class="row mt-2 justify-content-center mt-3 mb-4">
        <div class="fit mt-2 pl-5 pr-5">
            <div class="row justify-content-center">
                <a href="supplier.php?id=0" class="fit btn btn-outline-dark" title="Dashboard">Home</a>
                <a href="supplier.php?id=1" class="fit btn btn-outline-dark ml-4" title="view profile">Profile</a>
                <a href="supplier.php?id=2" class="fit btn btn-outline-info ml-4" title="view settings">Settings</a>
                <a href="supplier.php?logout" class="fit btn btn-outline-danger ml-4" title="Sign out">Logout</a>
            </div>
        </div>
    </div>
    <?php

if ($_GET['id'] != 3):
?>

<div class="row mt-2 justify-content-center mt-3">
    <div class="fit mt-2">
        <div class="row justify-content-center">
            <a href="supplier.php?id=3" class="fit btn btn-outline-info" title="view my sent responses">Response</a>
        </div>
    </div>
</div>

<?php

endif;

if (isset($_SESSION['login-message'])) :
?>

<div class="row justify-content-around mt-4">
    <div class="fit <?php echo $_SESSION['login-success'];?>"><?php echo $_SESSION['username'].'&nbsp;'.$_SESSION['login-message'];?></div>
</div>

<?php

unset($_SESSION['login-message']);
unset($_SESSION['login-success']);

endif;

switch (id) {
    case 0:

        $_SESSION['phone'] = $details['phone'];
        $get = "select * from list;";
        $fetch = $net->prepare($get);
        $fetch->execute();
        $sent = $fetch->get_result();
        $requests = mysqli_fetch_all($sent, MYSQLI_ASSOC);

        if (empty($requests)):
?>

<div class="row justify-content-center mt-5">
    <div class="fit alert alert-info">
        No requests available
    </div>
</div>

<?php 
    endif;
    foreach($requests as $request):
        $user = base64_encode($request['posted_by']);
        $item = base64_encode($request['name']);
        $description = base64_encode($request['description']);
        $dateposted = base64_encode($request['posted_on']);
        $response = base64_encode('yes');
?>

<div class="row justify-content-center mt-4">
    <div class="fit">Posted By :</div><div class="fit ml-2"><?php echo $request['posted_by'];?></div>
    <div class="fit ml-4">Posted On :</div><div class="fit ml-2"><?php echo $request['posted_on'];?></div>
</div>
<div class="row justify-content-center mt-3">
    <div class="fit">Item Name :</div><div class="fit ml-2"><?php echo $request['name'];?></div>
</div>
<div class="row justify-content-center mt-3">
    <div class="fit">Description :</div>
</div>
<div class="row justify-content-center mt-1">
    <div class="fit"><pre><?php echo $request['description'];?></pre></div>
</div>
<div class="row justify-content-center mb-3">
    <div class="fit">
        <p class="text-center">Are you able to provide the item ? 
            <a href="supplier.php?id=0&&user=<?php echo $user;?>&&item=<?php echo $item;?>&&description=<?php echo $description;?>&&dateposted=<?php echo $dateposted;?>" title="submit response to user <?php echo $request['posted_by'];?>">yes</a>
        </p>
    </div>
</div>

<?php
        endforeach;
        break;
    case 1:
?>

<div class="row justify-content-center mt-4">
    <table cellpadding="6">
        <tr>
            <td>Names :</td>
            <td><?php echo $details['names'];?></td>
        </tr>
        <tr>
            <td>Account :</td>
            <?php if($details['verified'] == false):?>
                <td colspan="2">Not verified</td>
                <td>Click on the link <br> we sent to <b><?php echo $_SESSION['email'];?></b></td>
            <?php else: ?>
                <td colspan="2">Verified</td>
            <?php endif;?>
        </tr>
        <tr>
            <td>Username :</td>
            <td><?php echo $_SESSION['username'];?></td>
        </tr>
        <tr>
            <td>Email :</td>
            <td><?php echo $_SESSION['email'];?></td>
        </tr>
        <tr>
            <td>Phone :</td>
            <td><?php echo $details['phone'];?></td>
        </tr>
    </table>
</div>

<?php
        break;
    case 2:
?>

<div class="row mt justify-content-center mt-4">
    <form action="supplier.php?id=2" method="post" class="alert bg-dark">
        <div class="form-group">
            <input type="password" name="pass" class="form form-control" placeholder="New password" required>
        </div>
        <div class="form-group">
            <input type="password" name="conf_pass" class="form form-control" placeholder="Confirm new password" required>
        </div>
        <div class="form-group">
            <button type="submit" name="change-supplier-pass" class="btn btn-outline-success" title="change password">Update</button>
        </div>
    </form>
</div>
<div class="row mt justify-content-center mt-3 mb-3" >
    <div class="fit"><a href="javascript:void(0)" id="delete-btn" class="btn btn-outline-danger" title="delete account">Delete Account</a></div>
    <div class="fit"><a href="javascript:void(0)" id="cancel-delete-btn" class="btn btn-outline-info" title="don't delete account" hidden>Cancel Delete Account</a></div>
</div>
<div id="delete-pop" class="row mt justify-content-center mt-3 mb-3" hidden>
    <form action="supplier.php?id=2" method="post" class="alert">
        <div class="form-group">
            <div class="input-group">
                <input type="password" name="password" class="form form-control" placeholder="Password" required="required">
                <div class="input-group-append">
                    <button type="submit" name="delete-account-supplier" class="btn btn-outline-danger input-group-text" title="delete account">Delete</button>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
    document.getElementById('delete-btn').onclick = function () {
        document.getElementById('delete-btn').hidden = true;
        document.getElementById('cancel-delete-btn').hidden = false;
        document.getElementById('delete-pop').hidden = false;
    }
    document.getElementById('cancel-delete-btn').onclick = function () {
        document.getElementById('cancel-delete-btn').hidden = true;
        document.getElementById('delete-pop').hidden = true;
        document.getElementById('delete-btn').hidden = false;
    }
    
</script>
<?php
        break;
    case 3:
?>

<div class="row justify-content-center mt-4 mb-3" >
    <div class="fit">
        <h4 class="text-center">Want List Responses</h4>
    </div>
</div>

<?php
        $get = "select * from response where responded_by = ?;";
        $fetch = $net->prepare($get);
        $fetch->bind_param('s',$_SESSION['username']);
        $fetch->execute();
        $sent = $fetch->get_result();
        $count = $sent->num_rows;
        if ((empty($count))or ($count == 0)):
?>

<div class="row justify-content-center mt-5">
<div class="fit alert alert-info">
    No responses available
</div>
</div>

<?php 
endif;
$requests = mysqli_fetch_all($sent, MYSQLI_ASSOC);
foreach($requests as $request):
    $user = base64_encode($request['posted_by']);
    $item = base64_encode($request['name']);
    $description = base64_encode($request['description']);
    $dateposted = base64_encode($request['posted_on']);
    $response = base64_encode('yes');
?>

<div class="row justify-content-center mt-4">
    <div class="fit">Posted By :</div><div class="fit ml-2"><?php echo $request['posted_by'];?></div>
    <div class="fit ml-4">Posted On :</div><div class="fit ml-2"><?php echo $request['posted_on'];?></div>
</div>
<div class="row justify-content-center mt-3">
    <div class="fit">Item Name :</div><div class="fit ml-2"><?php echo $request['name'];?></div>
</div>
<div class="row justify-content-center mt-3">
    <div class="fit">Description :</div>
</div>
<div class="row justify-content-center mt-1">
    <div class="fit"><pre><?php echo $request['description'];?></pre></div>
</div>



<div class="row justify-content-center mb-5">
    <div class="fit">Responded By :</div><div class="fit ml-2"><?php echo $request['responded_by'];?></div>
    <div class="fit ml-4">Responded On :</div><div class="fit ml-2"><?php echo $request['responded_on'];?></div>
</div>

<?php
        endforeach;
        break;
}
?>
<?php endif;?>
</div>
</body>
</html>